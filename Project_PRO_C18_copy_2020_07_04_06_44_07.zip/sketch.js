var monkey,ming;
var jungle,jimg;
var banana,bimg;
var stone,simg;
var ground,gimg;
var inn;
var score;
var fr,st;

function preload(){
  ming=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  bimg=loadImage("Banana.png");
  jimg=loadImage("jungle.jpg");
  simg=loadImage("stone.png");
}


function setup() {
  createCanvas(600,300);
    jungle=createSprite(300,150,20,20);
  jungle.addImage(jimg);
   jungle.velocityX=-9
  monkey=createSprite(50,220,10,10);
  monkey.scale=0.1;
  monkey.addAnimation("run",ming);
  monkey.velocityY=monkey.velocityY+0.8;

  inn=createSprite(300,290,1200,10);
  inn.visible=false;
  score=0;
  fr=new Group();
  st=new Group();
}


function draw(){
  background(255); 
 
monkey.velocityX=0
  
  fruits();
  stones();
  if(jungle.x<150){
    jungle.x=jungle.width/2;
 }
  monkey.velocityY=0;
  monkey.velocityY=monkey.velocityY+3
  monkey.collide(inn);
  if(keyDown("space") && monkey.y>250){
    monkey.velocityY=-120;
  }
  
  if(monkey.isTouching(fr)){
       score=score+10 ;
      fr.destroyEach();
     }
     if(monkey.isTouching(st)){
       score=score-5
       st.destroyEach();
     }
  drawSprites();
  
    text("SCORE " + score,500,20);
  
}

function fruits(){
  if(frameCount%50===0){
      banana=createSprite(560,150,10,10);
  banana.scale=0.04;
  banana.addImage(bimg);
    banana.x=random(200,390);
    banana.velocityX=-(5+2*score/50);
    banana.lifetime=80;
    fr.add(banana);
  }
}

function stones(){
  if(frameCount%60===0){
       stone=createSprite(560,280,10,10);
  stone.scale=0.1;
  stone.addImage(simg);
    stone.velocityX=-(4+2*score/50);
    stone.x=random(200,380);
    stone.lifetime=80;
    st.add(stone);
  } 
}












